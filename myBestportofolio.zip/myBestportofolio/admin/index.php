<?php
// Start a session if one isn't already active
if(session_status() == PHP_SESSION_NONE) { 
    session_start(); 
}

// Connect to the database
require(__DIR__ . '/../include/db.php');
$db = $conn;

// Check if user is logged in, if not send them to login page
if(!isset($_SESSION['isUserLoggedIn']) || $_SESSION['isUserLoggedIn'] !== true){
    header("Location: login.php"); 
    exit;
}

// Get all data from different tables to use in the admin panel
$home = $db->query("SELECT * FROM home WHERE id=1")->fetch_assoc();
$section_control = $db->query("SELECT * FROM section_control WHERE id=1")->fetch_assoc();
$social_media = $db->query("SELECT * FROM social_media WHERE id=1")->fetch_assoc();
$about = $db->query("SELECT * FROM about WHERE id=1")->fetch_assoc();
$seo = $db->query("SELECT * FROM seo WHERE id=1")->fetch_assoc();
$admin = $db->query("SELECT * FROM admin WHERE id=1")->fetch_assoc();
?>

<!DOCTYPE html>
<html>
<head>
  <!-- Basic page setup -->
  <meta charset="utf-8">
  <title>Admin Panel | Franklin Ngangu</title>
  
  <!-- CSS files -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 
  <!-- Custom styles for the admin panel -->
  <style>
    body { font-family: 'Source Sans Pro', sans-serif; background-color: #f4f4f4; }
    .content-wrapper { padding: 20px; }
    .card { border-radius: 15px; box-shadow: 0 8px 20px rgba(0,0,0,0.1); margin-bottom: 25px; }
    .card-header { border-top-left-radius: 15px; border-top-right-radius: 15px; color: #fff; font-weight: 600; font-size: 1.2rem; background: #1e3c72; }
    .form-control { border-radius: 10px; border: 1px solid #000; box-shadow: none; }
    .btn { border-radius: 10px; font-weight: 600; transition: all 0.3s ease; background-color: #1e3c72; color: #fff; border: none; }
    .btn:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
    .sidebar-dark-primary { background-color: #000; }
    .sidebar-dark-primary .brand-link { background-color: #1e3c72; color: #fff; font-weight: bold; }
    .sidebar-dark-primary .nav-sidebar .nav-item .nav-link.active { background-color: #1e3c72; color: #fff; border-radius: 8px; }
    .user-panel img { border-radius: 50%; border: 2px solid #fff; }
    footer.main-footer { background-color: #000; color: #fff; text-align: center; padding: 10px 0; font-weight: 500; }
  </style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Top navigation bar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item"><a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a></li>
    </ul>
    <ul class="navbar-nav ml-auto">
      <li class="nav-item"><a class="nav-link" href="../include/logout.php">Logout</a></li>
    </ul>
  </nav>

  <!-- Sidebar menu -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="#" class="brand-link">
      <img src="" class="brand-image img-circle elevation-3">
      <span class="brand-text font-weight-light">Ngangu Coding City</span>
    </a>
    <div class="sidebar">
      <!-- Admin profile section -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image"><img src="../images/<?=$admin['admin_profile']?>" class="img-circle elevation-2"></div>
        <div class="info"><a href="#" class="d-block"><?=$admin['fullname']?></a></div>
      </div>
      
      <!-- Main menu links -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column">
          <li class="nav-item"><a href="#section" class="nav-link">Section Control</a></li>
          <li class="nav-item"><a href="#home" class="nav-link">Home Setting</a></li>
          <li class="nav-item"><a href="#about" class="nav-link">About Setting</a></li>
          <li class="nav-item"><a href="#portfolio" class="nav-link">Portfolio Setting</a></li>
          <li class="nav-item"><a href="#skills" class="nav-link">Skills</a></li>
          <li class="nav-item"><a href="#social" class="nav-link">Social Media</a></li>
          <li class="nav-item"><a href="#seo" class="nav-link">SEO Setting</a></li>
          <li class="nav-item"><a href="#adminaccount" class="nav-link">Admin Account</a></li>
        </ul>
      </nav>
    </div>
  </aside>

  <!-- Main content area -->
  <div class="content-wrapper">

    <!-- Display success messages if any -->
    <?php if(isset($_SESSION['success_message'])): ?>
      <div class="container mt-3">
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <?= $_SESSION['success_message'] ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      </div>
      <?php unset($_SESSION['success_message']); endif; ?>

    <section class="content">
      <div class="container-fluid">

        <!-- SECTION 1: Control which sections are visible on the website -->
        <div id="section" class="card card-primary">
          <div class="card-header"><h3 class="card-title">Section Control</h3></div>
          <div class="card-body">
            <form method="POST" action="../include/admin.php">
              <!-- Checkboxes to show/hide sections -->
              <div class="form-check"><input type="checkbox" name="home" value="1" class="form-check-input" <?= $section_control['home_section']?'checked':'' ?>><label class="form-check-label">Home Section</label></div>
              <div class="form-check"><input type="checkbox" name="about" value="1" class="form-check-input" <?= $section_control['about_section']?'checked':'' ?>><label class="form-check-label">About Section</label></div>
              <div class="form-check"><input type="checkbox" name="resume" value="1" class="form-check-input" <?= $section_control['resume_section']?'checked':'' ?>><label class="form-check-label">Resume Section</label></div>
              <div class="form-check"><input type="checkbox" name="portfolio" value="1" class="form-check-input" <?= $section_control['portfolio_section']?'checked':'' ?>><label class="form-check-label">Portfolio Section</label></div>
              <div class="form-check"><input type="checkbox" name="contact" value="1" class="form-check-input" <?= $section_control['contact_section']?'checked':'' ?>><label class="form-check-label">Contact Section</label></div>
              <br><button class="btn btn-primary" name="update-section">Update Sections</button>
            </form>
          </div>
        </div>

        <!-- SECTION 2: Home page settings -->
        <div id="home" class="card card-info">
          <div class="card-header"><h3 class="card-title">Home Setting</h3></div>
          <div class="card-body">
            <form method="POST" action="../include/admin.php">
              <div class="form-group"><label>Title</label><input type="text" name="title" class="form-control" value="<?=$home['title']?>"></div>
              <div class="form-group"><label>Subtitle</label><input type="text" name="subtitle" class="form-control" value="<?=$home['subtitle']?>"></div>
              <div class="form-check"><input type="checkbox" name="showicons" value="1" class="form-check-input" <?=$home['showicons']?'checked':''?>><label class="form-check-label">Show Icons</label></div>
              <button class="btn btn-info" name="update-home">Update Home</button>
            </form>
          </div>
        </div>

        <!-- SECTION 3: About page settings -->
        <div id="about" class="card card-warning">
          <div class="card-header"><h3 class="card-title">About Setting</h3></div>
          <div class="card-body">
            <form method="POST" action="../include/admin.php" enctype="multipart/form-data">
              <div class="form-group"><label>Title</label><input type="text" name="abouttitle" class="form-control" value="<?=$about['about_title']?>"></div>
              <div class="form-group"><label>Subtitle</label><input type="text" name="aboutsubtitle" class="form-control" value="<?=$about['about_subtitle']?>"></div>
              <div class="form-group"><label>Description</label><textarea name="aboutdesc" class="form-control"><?=$about['about_desc']?></textarea></div>
              <div class="form-group"><label>Profile Picture</label><input type="file" name="profile" class="form-control"><img src="../images/<?=$about['profile_pic']?>" style="width:100px;margin-top:10px;"></div>
              <button class="btn btn-warning" name="update-about">Update About</button>
            </form>
          </div>
        </div>

        <!-- SECTION 4: Portfolio settings -->
        <div id="portfolio" class="card card-success">
          <div class="card-header"><h3 class="card-title">Portfolio Setting</h3></div>
          <div class="card-body">
            <form method="POST" action="../include/admin.php" enctype="multipart/form-data">
              <div class="form-group"><label>Project Type</label><input type="text" name="type" class="form-control"></div>
              <div class="form-group"><label>Project Name</label><input type="text" name="project_name" class="form-control"></div>
              <div class="form-group"><label>Project Link</label><input type="text" name="project_link" class="form-control"></div>
              <div class="form-group"><label>Project Image</label><input type="file" name="project_pic" class="form-control"></div>
              <button class="btn btn-success" name="add-project">Add Project</button>
            </form>
          </div>
        </div>

        <!-- SECTION 5: Skills management -->
        <div id="skills" class="card card-primary">
          <div class="card-header"><h3 class="card-title">Manage Skills</h3></div>
          <div class="card-body p-0">
            <!-- Table showing existing skills -->
            <table class="table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Skill Name</th>
                  <th>Skill Level</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                // Get all skills from database
                $q = "SELECT * from skills";
                $r=mysqli_query($db,$q);
                $c =1;
                while($skill=mysqli_fetch_array($r)){
                ?>
                <tr>
                  <td><?=$c?></td>
                  <td><?=$skill['skill_name']?></td>
                  <td>
                    <div class="progress progress-xs">
                      <div class="progress-bar progress-bar-danger" style="width: <?=$skill['skill_level']?>%"></div>
                    </div>
                    <span class="badge bg-danger"><?=$skill['skill_level']?>%</span>
                  </td>
                  <td><a href="../include/deleteskill.php?id=<?=$skill['id']?>">Delete</a></td>
                </tr>
                <?php $c++; } ?>
              </tbody>
            </table>
          </div>

          <!-- Form to add new skills -->
          <form role="form" action="../include/admin.php" method="post">
            <div class="card-body">
              <div class="form-group col-6"><label>Skill Name</label><input type="text" class="form-control" name="skillname"></div>
              <div class="form-group col-6"><label>Skill Level</label><input type="range" min="1" max="100" class="form-control" name="skilllevel"></div>
            </div>
            <div class="card-footer"><button type="submit" name="add-skill" class="btn btn-primary">Add Skill</button></div>
          </form>
        </div>

        <!-- SECTION 6: Social media links -->
        <div id="social" class="card card-dark">
          <div class="card-header"><h3 class="card-title">Social Media</h3></div>
          <div class="card-body">
            <form method="POST" action="../include/admin.php">
              <div class="form-group"><label>Stackoverflow</label><input type="text" name="instagram" class="form-control" value="<?=$social_media['instagram']?>"></div>
              <div class="form-group"><label>Github</label><input type="text" name="skype" class="form-control" value="<?=$social_media['skype']?>"></div>
              <div class="form-group"><label>LinkedIn</label><input type="text" name="linkedin" class="form-control" value="<?=$social_media['linkedin']?>"></div>
              <button class="btn btn-dark" name="update-socialmedia">Update Social Media</button>
            </form>
          </div>
        </div>

        <!-- SECTION 7: SEO settings -->
        <div id="seo" class="card card-secondary">
          <div class="card-header"><h3 class="card-title">SEO Settings</h3></div>
          <div class="card-body">
            <form method="POST" action="../include/admin.php">
              <div class="form-group"><label>Meta Title</label><input type="text" class="form-control" name="metatitle" value="<?=$seo['meta_title']?>"></div>
              <div class="form-group"><label>Meta Description</label><input type="text" class="form-control" name="metadesc" value="<?=$seo['meta_description']?>"></div>
              <div class="form-group"><label>Meta Keywords</label><input type="text" class="form-control" name="metakeywords" value="<?=$seo['meta_keywords']?>"></div>
              <button class="btn btn-secondary" name="update-seo">Update SEO</button>
            </form>
          </div>
        </div>

        <!-- SECTION 8: Admin account settings -->
        <div id="adminaccount" class="card card-danger">
          <div class="card-header"><h3 class="card-title">Admin Account</h3></div>
          <div class="card-body">
            <form method="POST" action="../include/admin.php" enctype="multipart/form-data">
              <div class="form-group"><label>Full Name</label><input type="text" class="form-control" name="fullname" value="<?=$admin['fullname']?>"></div>
              <div class="form-group"><label>Username</label><input type="text" class="form-control" name="username" value="<?=$admin['username']?>"></div>
              <div class="form-group"><label>Password</label><input type="password" class="form-control" name="password" value="<?=$admin['password']?>"></div>
              <div class="form-group"><label>Profile Picture</label><input type="file" class="form-control" name="profile"><img src="../images/<?=$admin['admin_profile']?>" style="width:100px;margin-top:10px;"></div>
              <button class="btn btn-danger" name="update-admin">Update Admin</button>
            </form>
          </div>
        </div>

      </div>
    </section>
  </div>

  <!-- Footer -->
  <footer class="main-footer">
    <strong>&copy; 2025 Franklin Ngangu. All rights reserved.</strong>
  </footer>
</div>

<!-- JavaScript files -->
<script src="plugins/jquery/jquery.min.js"></script>
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="dist/js/adminlte.min.js"></script>
</body>
</html>