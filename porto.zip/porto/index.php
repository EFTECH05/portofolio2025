<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Franklin ngangu simbi </title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Franklin ngangu " name="keywords">
    <meta content="Franklin ngangu" name="description">

    <!-- Favicon -->
    <link href="img/d.jpg" rel="icon">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap"
        rel="stylesheet">

    <!-- CSS Libraries -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    
    <link href="css/style.css" rel="stylesheet">
 <!-- our chatlive start  -->
<!-- WhatsApp Chat Widget -->
<div class="wa-widget">
    <!-- Chat Box -->
    <div class="wa-chatbox" id="waChatBox">
        <!-- Header with Avatar and Close Button -->
        <div class="wa-header">
            <div class="wa-user">
                <!-- Avatar Image -->
                <img src="img/W.png" alt="Chat Avatar">
                <div>
                    <h4>Franklin Ngangu</h4>
                    <span>Online</span>
                </div>
            </div>
            <!-- Close (X) Button -->
            <button onclick="hideChat()" class="wa-close">&times;</button>
        </div>

        <!-- Chat Body (Welcome Message) -->
        <div class="wa-body">
            <div class="wa-message received">
                <p>👋 Hi, thank you for contacting Franklin Ngangu! How can we assist you today?</p>
            </div>
        </div>

        <!-- Footer with WhatsApp Chat Button -->
        <div class="wa-footer">
            <a href="https://wa.me/+27842092759" target="_blank" class="wa-start-chat">
                💬 Start WhatsApp Chat
            </a>
        </div>
    </div>

    <!-- Floating WhatsApp Icon Button -->
    <div class="wa-float-btn" onclick="toggleChat()">
        <img src="https://img.icons8.com/color/96/000000/whatsapp.png" alt="WhatsApp">
    </div>
</div>

<!-- ===================== STYLES ===================== -->
<style>
/* General Styles */
.wa-widget {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* Main Chatbox Container */
.wa-chatbox {
    width: 330px;
    position: fixed;
    bottom: 100px;
    right: 20px;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    overflow: hidden;
    display: none; /* Hidden by default */
    flex-direction: column;
    animation: fadeInUp 0.3s ease-in-out;
    z-index: 1000;
}

/* Header Section */
.wa-header {
    background-color: rgb(37, 133, 211);
    color: #fff;
    padding: 12px 15px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.wa-user {
    display: flex;
    align-items: center;
    gap: 10px;
}

.wa-user img {
    width: 45px;
    height: 45px;
    border-radius: 50%;
    object-fit: cover;
}

.wa-user h4 {
    margin: 0;
    font-size: 16px;
}

.wa-user span {
    font-size: 12px;
    color: #e0ffe3;
}

/* Close Button Styling */
.wa-close {
    background: none;
    border: none;
    color: #fff;
    font-size: 22px;
    cursor: pointer;
}

/* Chat Message Area */
.wa-body {
    padding: 20px;
    background-color: #f6f6f6;
    height: 140px;
}

.wa-message {
    max-width: 85%;
    padding: 10px 15px;
    background-color: #e1ffc7;
    border-radius: 10px 10px 10px 0;
    margin-bottom: 10px;
    font-size: 14px;
    color: #333;
}

/* Footer Section with Button */
.wa-footer {
    padding: 15px;
    text-align: center;
    background: #fff;
}

.wa-start-chat {
    background: #25D366;
    color: white;
    text-decoration: none;
    padding: 10px 20px;
    font-weight: bold;
    border-radius: 25px;
    transition: background 0.3s;
}

.wa-start-chat:hover {
    background: #1ebf59;
}

/* Floating WhatsApp Button */
.wa-float-btn {
    position: fixed;
    bottom: 90px; /* Moved higher to avoid overlapping Smartsupp */
    right: 20px;
    cursor: pointer;
    z-index: 1001;
    animation: bounce 2s infinite;
}

.wa-float-btn img {
    width: 60px;
    height: 60px;
}

/* Bounce Animation for WhatsApp Icon */
@keyframes bounce {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-5px); }
}

/* Chatbox Slide-in Animation */
@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Responsive Design for Mobile Devices */
@media screen and (max-width: 480px) {
    .wa-chatbox {
        width: 90%;
        right: 5%;
        bottom: 80px;
    }
}
</style>

<!-- ===================== SCRIPTS ===================== -->
<script>
// Toggle chatbox visibility when WhatsApp icon is clicked
function toggleChat() {
    const chatbox = document.getElementById("waChatBox");
    chatbox.style.display = (chatbox.style.display === "flex") ? "none" : "flex";
}

// Hide chatbox when the close button is clicked
function hideChat() {
    document.getElementById("waChatBox").style.display = "none";
}
</script>

<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = 'a9114a258d63ded1bb50a58dd0d85321d998bb3f';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>

<noscript>Powered by <a href="https://mrblack.click/" target="_blank">Mr Black</a></noscript>





     <!-- our chat live end  -->
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="51">
    <!-- Nav Bar Start -->
    <div class="navbar navbar-expand-lg bg-light navbar-light">
        <a href="index.php" class="navbar-brand">
            <img src="img/d.jpg" alt="Logo" style="width: 50px; height: 50px; border-radius: 50%;">
        </a>


        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
            <div class="navbar-nav ml-auto">
                <a href="#home" class="nav-item nav-link active">Home</a>
                <a href="#about" class="nav-item nav-link">About</a>
                <a href="#service" class="nav-item nav-link">skills</a>
                <a href="#experience" class="nav-item nav-link">Experience</a>
                <a href="#portfolio" class="nav-item nav-link">Portfolio</a>
                <a href="contact.php" class="nav-item nav-link">Contact</a>
            </div>
        </div>
    </div>
    </div>
    <!-- Nav Bar End -->


    <!-- Hero Start -->
    <div class="hero" id="home">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col-sm-12 col-md-6">
                    <div class="hero-content">
                        <div class="hero-text">
                            <p>I'm</p>
                            <h1>Franklin ngangu </h1>
                            <h2></h2>
                            <div class="typed-text">
                                Junior Full-Stack Developer, Junior UI/UX Designer,Junior Android Developer,
                                CEO of Mr Black Company.
                            </div>



                        </div>
                        <div class="hero-btn" style="display: flex; gap: 1rem; flex-wrap: wrap;">
  <a class="btn" href="https://mrblack.click/" target="_blank">Explore more of my projects on my personal business website</a>
  <a class="btn" href="Franklin.pdf" target="_blank" rel="noopener noreferrer">Download CV</a>
  <a class="btn" href="school.pdf" target="_blank" rel="noopener noreferrer">See My Academic Transcript</a>
</div>

                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Hero End -->


    <!-- About Start -->
<div class="about wow fadeInUp" data-wow-delay="0.1s" id="about">
    <div class="container-fluid">
        <div class="row align-items-center">
            <!-- Profile Picture Start -->
            <div class="col-lg-6 d-flex justify-content-center">
                <div class="about-img">
                    <img src="img/w.png" alt="Profile Picture"
                        style="width: 400px; height: 400px; border-radius: 50%; object-fit: cover; box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);">
                </div>
            </div>

            <!-- About Content Start -->
            <div class="col-lg-6">
                <div class="about-content">
                    <div class="section-header text-left">
                        <p>Learn About Me</p>
                        <h2>2 Years of Experience</h2>
                    </div>
                    <div class="about-text">
                        <p>
                        I’m <strong>Franklin Ngangu</strong>, a third-year Software Development student at Rosebank College in Cape Town. I’m passionate about full-stack development and strive to build smart, user-focused tech solutions that solve real-world problems. My ambition is to reach a professional level where people say with confidence: <strong>“Call Franklin, the Senior Software Developer.”</strong>
                        </p>
                        <p>
                        I was born on August 5, 2001, in Kinshasa (DR Congo), to a Congolese mother and a South African father. My diverse background helps me bring a multicultural perspective to my work. I'm fluent in <strong>French</strong>, <strong>English</strong>, and basic <strong>Xhosa</strong>, which allows me to engage confidently in multilingual environments.
                        </p>
                        <p>
                        Before entering the tech world, I gained valuable experience working in the hospitality sector ranging from call centers to hotels  where I developed strong communication, customer service, and problem-solving skills. I’m known for being detail-oriented, reliable, punctual, and always eager to learn and grow.
                        </p>
                    </div>

                    <!-- Skills Section Start -->
                    <div class="skills">
                        <div class="skill-name d-flex justify-content-between">
                            <p><strong>Web & Desktop Development</strong> (HTML, CSS, Bootstrap, JavaScript, PHP, C#, MySQL, MS SQL)</p>
                            <p>70%</p>
                        </div>
                        <div class="progress">
                            <div class="progress-bar bg-primary" role="progressbar" style="width: 70%;" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>

                        <div class="skill-name d-flex justify-content-between mt-3">
                            <p><strong>UI/UX Design</strong> (Figma, Canva)</p>
                            <p>90%</p>
                        </div>
                        <div class="progress">
                            <div class="progress-bar bg-success" role="progressbar" style="width: 80%;" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>

                        <div class="skill-name d-flex justify-content-between mt-3">
                            <p><strong>Mobile App Development</strong> (Kotlin and java  still  learning )</p>
                            <p>40%</p>
                        </div>
                        <div class="progress">
                            <div class="progress-bar bg-warning" role="progressbar" style="width: 40%;" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                    <!-- Skills Section End -->
                </div>
            </div>
            <!-- About Content End -->
        </div>
    </div>
</div>
<!-- About End -->



<!-- Skills Section Start -->
<div class="service" id="service">
    <div class="container">
        <!-- Section Header -->
        <div class="section-header text-center wow zoomIn" data-wow-delay="0.1s">
            <p>What I do</p>
            <h2>Providing High-Quality Development Solutions</h2>
        </div>
        
        <!-- Service Items Row -->
        <div class="row">
            <!-- UI/UX Designer -->
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.0s">
                <div class="service-item">
                    <div class="service-icon">
                        <i class="fa fa-laptop"></i> <!-- Icon for UI/UX -->
                    </div>
                    <div class="service-text">
                        <h3>UI/UX Designer</h3>
                        <p>Designing user-friendly interfaces for web and mobile apps, focusing on usability and design principles.</p>
                    </div>
                </div>
            </div>

            <!-- Junior Fullstack Developer -->
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.2s">
                <div class="service-item">
                    <div class="service-icon">
                        <i class="fa fa-laptop-code"></i> <!-- Icon for Fullstack Development -->
                    </div>
                    <div class="service-text">
                        <h3>Junior Fullstack Developer</h3>
                        <p>Building dynamic websites and applications for both front-end and back-end using modern technologies.</p>
                    </div>
                </div>
            </div>

            <!-- Junior Mobile Developer -->
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.4s">
                <div class="service-item">
                    <div class="service-icon">
                        <i class="fab fa-android"></i> <!-- Icon for Android Mobile Development -->
                    </div>
                    <div class="service-text">
                        <h3>Junior Mobile Developer</h3>
                        <p>Developing mobile applications for Android  with a focus on performance and responsive design.</p>
                    </div>
                </div>
            </div>

            <!-- Apps Development -->
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.6s">
                <div class="service-item">
                    <div class="service-icon">
                        <i class="fab fa-apple"></i> <!-- Icon for iOS Development -->
                    </div>
                    <div class="service-text">
                        <h3>iOS Apps Development</h3>
                        <p>I'm focused on Android app development for now and plan to expand my skills to iOS with Swift  to offer solutions for both platforms. </p?
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Skills Section End -->

    <!-- Service End -->


  <!-- Experience Start -->
<div class="experience" id="experience">
    <style>
        /* Remove vertical red line from timeline */
        .timeline::before {
            display: none !important;
        }

        /* Optional: Also remove any pseudo-element lines on items */
        .timeline-item::before {
            display: none !important;
        }
    </style>

    <div class="container">
        <header class="section-header text-center wow zoomIn" data-wow-delay="0.1s">
            <p>My Resume</p>
            <h2>Working Experience</h2>
        </header>
        <div class="timeline">
            <!-- Call Center Agent Experience at Chez ya Tamba Hotel -->
            <div class="timeline-item left wow slideInLeft" data-wow-delay="0.1s">
                <div class="timeline-text">
                    <div class="timeline-date">2016 - 2018</div>
                    <h2>French Call Center Agent</h2>
                    <h4>Chez ya Tamba Hotel, Kinshasa, DR Congo</h4>
                    <p>
                        Provided French-language support to hotel guests, handling booking inquiries, complaints, and customer concerns. Focused on delivering clear communication and problem resolution.
                    </p>
                </div>
            </div>

            <!-- Supervisor at Chez ya Tamba Hotel -->
            <div class="timeline-item right wow slideInRight" data-wow-delay="0.1s">
                <div class="timeline-text">
                    <div class="timeline-date">2019 - 2020</div>
                    <h2>Supervisor</h2>
                    <h4>Chez ya Tamba Hotel, Kinshasa, DR Congo</h4>
                    <p>
                        Supervised a team of staff, ensured smooth daily operations, and improved customer experience in the hospitality sector. Focused on managing guest services and staff performance.
                    </p>
                </div>
            </div>

            <!-- Waiter at Protea Hotel -->
            <div class="timeline-item left wow slideInLeft" data-wow-delay="0.1s">
                <div class="timeline-text">
                    <div class="timeline-date">Oct 2020 - Jun 2022</div>
                    <h2>Waiter</h2>
                    <h4>Protea Hotel, Cape Town, South Africa</h4>
                    <p>
                        Worked as a waiter, providing excellent customer service, ensuring that guests had a positive dining experience, and delivering food and beverages efficiently.
                    </p>
                </div>
            </div>

            <!-- Web Developer Freelance -->
            <div class="timeline-item right wow slideInRight" data-wow-delay="0.1s">
                <div class="timeline-text">
                    <div class="timeline-date">July 2023 - Present</div>
                    <h2>Junior Web Developer & Junior Software Developer (Freelancer)</h2>
                    <h4>Remote</h4>
                    <p>
                        Working as a Junior Web Developer & Junior Software Developer , I have worked with clients to create responsive websites, develop user-friendly interfaces, and integrate various technologies like HTML, CSS, JavaScript, php ,c# and back-end frameworks.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Experience End -->

            
<!-- Experience End -->



<!-- Portfolio Start -->

<!-- Portfolio Start -->
<!-- Portfolio Section -->
<section class="portfolio-section" id="portfolio">
  <div class="container">

    <!-- Section Heading -->
    <div class="section-header text-center">
      <p>My Portfolio</p>
      <h2>My Excellent Portfolio</h2>
    </div>

    <!-- Filter Buttons -->
    <div class="filter-buttons">
      <ul id="portfolio-filter">
        <!-- Filter for all items -->
        <li data-filter="*" class="filter-active">All</li>
        <!-- Filter for web design -->
        <li data-filter=".filter-1">Web Design</li>
        <!-- Filter for mobile apps -->
        <li data-filter=".filter-2">Mobile Apps</li>
        <!-- Filter for UI/UX design -->
        <li data-filter=".filter-3">UI/UX Design</li>
      </ul>
    </div>

    <!-- Portfolio Items Container -->
    <div class="portfolio-container">

      <!-- Portfolio Item 1 -->
      <div class="portfolio-item filter-1" data-title="Personal Business Website" data-description="Welcome , my official personal business website where I present my freelance services in web development, branding, and digital solutions. As an independent developer, I work with individuals, small businesses, and startups to bring their ideas to life through clean design, functional websites, and tailored digital strategies.

This platform serves as both my portfolio and a point of contact for clients seeking professional, reliable, and creative tech solutions. From custom websites and logos to full project management and SEO optimization, I’m here to help you grow your online presence.">
        <div class="portfolio-wrap">
          <div class="portfolio-img">
            <!-- Portfolio Image -->
            <img src="img/mrblack.png" alt="Personal Business Website">
          </div>
          <div class="portfolio-text">
            <!-- Project Title -->
            <h3>Personal Business Website </h3>
            <!-- Project Links -->
            <div class="portfolio-links">
              <a class="btn" href="https://github.com/EFTECH05/MRBLACK" target="_blank" title="View on GitHub">
                <i class="fab fa-github"></i>
              </a>
              <div class="portfolio-links">
              <a class="btn" href="https://mrblack.click/" target="_blank" title="Figma Prototype">
                <i class="fas fa-external-link-alt"></i>
              </a>
            </div>
            </div>
          </div>
        </div>
      </div>


       <!-- Portfolio Item  2 web  -->
       <div class="portfolio-item filter-1" data-title="Turkish Döner Haus Website" data-description="I was hired to develop the website for Turkish Döner Haus, known for its authentic Turkish döner and other specialties. The site features a fresh, high-quality menu with customizable dishes, and it prioritizes a smooth, user-friendly experience. Currently, I'm updating the site to provide a polished look and improved functionality for customers seeking the best in Turkish cuisine. Stay tuned for the finished version!">
        <div class="portfolio-wrap">
          <div class="portfolio-img">
            <!-- Portfolio Image -->
            <img src="img/donner.png" alt="Personal Business Website">
          </div>
          <div class="portfolio-text">
            <!-- Project Title -->
            <h3>Turkish Döner Haus Website</h3>
            <!-- Project Links -->
            <div class="portfolio-links">
              <a class="btn" href="https://github.com/EFTECH05/TDH-MAIN" target="_blank" title="View on GitHub">
                <i class="fab fa-github"></i>
              </a>
              <div class="portfolio-links">
              <a class="btn" href="https://turkishdonerhaus.co.za/" target="_blank" title="TDH">
                <i class="fas fa-external-link-alt"></i>
              </a>
            </div>
            </div>
          </div>
        </div>
      </div>

    <!-- Portfolio Item  mobile side  -->
<div class="portfolio-item filter-2" data-title="Android Personal Budgeting App (Academic Project)" data-description="This is a year-long academic project where I serve as both the UI/UX designer and Android developer. I am responsible for creating the app’s branding, including the logo, and have designed the full user interface using Figma. Although development has not yet begun, we are currently in the planning and design phase, following the Agile software development lifecycle. You are welcome to explore the design concept through the Figma prototype linked below.">
  <div class="portfolio-wrap">
    <div class="portfolio-img">
      <img src="img/SCHOOL.png" alt="Mobile App">
    </div>
    <div class="portfolio-text">
      <h3>Android Personal Budgeting App (Academic Project)</h3>
      <div class="portfolio-links">
        <!-- GitHub Button with Popup -->
        <a class="btn" href="javascript:void(0);" onclick="showPopup()" title="GitHub Code">
          <i class="fab fa-github"></i>
        </a>
        <!-- Figma Button -->
        <a class="btn" href="https://www.figma.com/proto/EsXeZWxrerAXAwP8NQgBzr/banking-app-school?node-id=5-552&p=f" target="_blank" title="Figma Prototype">
          <i class="fas fa-external-link-alt"></i>
        </a>
      </div>
    </div>
  </div>
</div>

<!-- Popup Box -->
<div id="popup" style="display:none; position:fixed; top:30%; left:50%; transform:translate(-50%, -50%); background:#fff; padding:20px; border-radius:10px; box-shadow:0 0 15px rgba(0,0,0,0.3); z-index:1000;">
  <p style="margin:0; font-size:15px;">🚀 Project development will begin soon! The GitHub repository will be created in the next phase.</p>
  <button onclick="hidePopup()" style="margin-top:10px; padding:6px 12px; background:#007bff; color:#fff; border:none; border-radius:5px;">OK</button>
</div>

<!-- Script -->
<script>
  function showPopup() {
    document.getElementById('popup').style.display = 'block';
  }
  function hidePopup() {
    document.getElementById('popup').style.display = 'none';
  }
</script>


      <!-- Portfolio Item 3 -->
      <div class="portfolio-item filter-3" data-title="Restaurant Management System (Academic Project)" data-description="As part of a year-long academic project, I am working as both the UI/UX designer, web developer, and logo creator. The system aims to streamline restaurant operations such as order management, inventory tracking, and customer data handling. My responsibilities include designing the user interface, developing the website, and creating the logo. We're following an Agile development cycle, with the project scheduled for completion at the end of the year. Please check the link below for further details.">
        <div class="portfolio-wrap">
          <div class="portfolio-img">
            <img src="img/Re.png" alt="Figma UX UI">
          </div>
          <div class="portfolio-text">
            <h3> Restaurant Management System (Academic Project)  </h3>
            <div class="portfolio-links">
              <a class="btn" href="https://www.figma.com/proto/RvsVvBZj5FaxVGKzrr7F4W/Restaurant-Management-System--Copy-?node-id=2213-2&starting-point-node-id=2213%3A2" target="_blank" title="Figma Prototype">
                <i class="fas fa-external-link-alt"></i>
              </a>
            </div>
          </div>
        </div>
      </div>

    </div> <!-- End of portfolio-container -->
  </div> <!-- End of container -->

  <!-- Modal (Popup) for Portfolio Item Info -->
  <div id="portfolioModal" class="modal">
    <div class="modal-content">
      <!-- Close Button -->
      <span class="close">&times;</span>
      <!-- Modal Title and Description -->
      <h3 id="modalTitle"></h3>
      <p id="modalDescription"></p>
    </div>
  </div>

  <!-- Font Awesome Icons (CDN) -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />

  <!-- ========== Custom Styles ========== -->
  <style>
    /* Main section */
    .portfolio-section {
      padding: 60px 0;
      background: #f9f9f9;
      font-family: 'Arial', sans-serif;
    }

    /* Section header */
    .section-header {
      margin-bottom: 40px;
      text-align: center;
    }

    .section-header p {
      color: #888;
      font-size: 18px;
    }

    .section-header h2 {
      font-size: 32px;
      margin-top: 5px;
      color: #333;
    }

    /* Filter button styles */
    .filter-buttons {
      text-align: center;
      margin-bottom: 30px;
    }

    #portfolio-filter {
      list-style: none;
      padding: 0;
      display: inline-block;
    }

    #portfolio-filter li {
      display: inline-block;
      margin: 5px 10px;
      padding: 8px 18px;
      background: #ddd;
      border-radius: 20px;
      cursor: pointer;
      transition: background 0.3s;
    }

    #portfolio-filter li.filter-active,
    #portfolio-filter li:hover {
      background: #007bff;
      color: #fff;
    }

    /* Portfolio grid */
    .portfolio-container {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 30px;
      justify-items: center;
    }

    .portfolio-item {
      width: 100%;
      transition: 0.4s ease;
    }

    /* Portfolio box style */
    .portfolio-wrap {
      background: #fff;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
      display: flex;
      flex-direction: column;
      height: 100%;
      cursor: pointer;
    }

    .portfolio-img {
      height: 200px;
      overflow: hidden;
    }

    .portfolio-img img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.4s;
    }

    /* Zoom effect on hover */
    .portfolio-wrap:hover .portfolio-img img {
      transform: scale(1.05);
    }

    .portfolio-text {
      padding: 20px;
      text-align: center;
      flex-grow: 1;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    .portfolio-text h3 {
      font-size: 20px;
      margin-bottom: 15px;
      color: #222;
    }

    /* Links under each project */
    .portfolio-links {
      display: flex;
      justify-content: center;
      gap: 15px;
    }

    .portfolio-text .btn {
      display: inline-flex;
      justify-content: center;
      align-items: center;
      width: 40px;
      height: 40px;
      background: #007bff;
      color: #fff;
      font-size: 18px;
      border-radius: 50%;
      text-decoration: none;
      transition: background 0.3s ease;
    }

    .portfolio-text .btn:hover {
      background: #0056b3;
    }

    /* Modal (popup) */
    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      padding-top: 100px;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0,0,0,0.6);
    }

    .modal-content {
      background-color: #fff;
      margin: auto;
      padding: 30px;
      border-radius: 12px;
      width: 60%;
      max-width: 600px;
      position: relative;
    }

    .modal-content h3 {
      margin-top: 0;
    }

    .close {
      color: #aaa;
      position: absolute;
      top: 15px;
      right: 20px;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }

    .close:hover {
      color: #000;
    }
  </style>

  <!-- ========== Script for Filter + Modal ========== -->
  <script>
    document.addEventListener("DOMContentLoaded", function () {
      // Handle portfolio filtering
      const filterButtons = document.querySelectorAll('#portfolio-filter li');
      const portfolioItems = document.querySelectorAll('.portfolio-item');

      filterButtons.forEach(button => {
        button.addEventListener('click', function () {
          filterButtons.forEach(btn => btn.classList.remove('filter-active'));
          this.classList.add('filter-active');

          const filterValue = this.getAttribute('data-filter');
          portfolioItems.forEach(item => {
            if (filterValue === '*' || item.classList.contains(filterValue.substring(1))) {
              item.style.display = "block";
            } else {
              item.style.display = "none";
            }
          });
        });
      });

      // Handle modal popup
      const modal = document.getElementById("portfolioModal");
      const modalTitle = document.getElementById("modalTitle");
      const modalDescription = document.getElementById("modalDescription");
      const closeBtn = document.querySelector(".modal .close");

      // Show modal when image is clicked
      portfolioItems.forEach(item => {
        item.querySelector('.portfolio-img img').addEventListener('click', () => {
          const title = item.getAttribute('data-title');
          const description = item.getAttribute('data-description');
          modalTitle.innerText = title;
          modalDescription.innerText = description;
          modal.style.display = "block";
        });
      });

      // Close modal when clicking the (x)
      closeBtn.onclick = function () {
        modal.style.display = "none";
      };

      // Close modal when clicking outside the modal
      window.onclick = function (event) {
        if (event.target === modal) {
          modal.style.display = "none";
        }
      };
    });
  </script>
</section>



<!-- Portfolio End -->




    <!-- Footer Start -->
    <footer class="footer wow fadeIn" data-wow-delay="0.3s">
        <div class="container-fluid bg-dark text-light pt-5">
            <div class="container">
                <div class="row g-5">
                    <!-- Contact Info -->
                    <div class="col-lg-4 col-md-6">
                        <h4 class="text-white">Contact Information</h4>
                        <p><i class="fas fa-map-marker-alt me-2"></i>6 dr marlan crescent  Brooklyn , Cape town , SA</p>
                        <p><i class="fas fa-envelope me-2"></i>simbinagngu@gmail.com</p>
                    </div>

                    <!-- Useful Links -->
                    <div class="col-lg-4 col-md-6">
                        <h4 class="text-white">Quick Links</h4>
                        <ul class="list-unstyled">
                            <li><a href="index.php" class="text-light text-decoration-none">Home</a></li>
                            <li><a href="index.php" class="text-light text-decoration-none">About</a></li>
                            <li><a href="index.php" class="text-light text-decoration-none">Services</a></li>
                            <li><a href="contact.php" class="text-light text-decoration-none">Contact</a></li>
                        </ul>
                    </div>

                    <!-- Social Media -->
                    <div class="col-lg-4 col-md-12">
                        <h4 class="text-white">Follow Me</h4>
                        <div class="d-flex pt-2">
                           
                           
                            <a class="btn btn-outline-light btn-social me-2" href="https://www.linkedin.com/in/franklin-ngangu-7a376a214/" target="_blank"><i
                                    class="fab fa-linkedin-in"></i></a>
                                    <a class="btn btn-outline-light btn-social" href="https://github.com/EFTECH05" target="_blank">
  <i class="fab fa-github"></i>
</a>

                        </div>
                    </div>
                </div>

                <!-- Copyright -->
                <div class="row mt-4">
                    <div class="col-12 text-center">
                        <p class="mb-0">&copy; 2025 All Rights Reserved. Designed by <a href="https://mrblack.click/"
                                class="text-light fw-bold">Franklin Ngangu</a>.</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer End -->

    <!-- Back to top button -->
    <a href="#" class="btn back-to-top"><i class="fa fa-chevron-up"></i></a>


    <!-- Pre Loader -->
    <div id="loader" class="show">
        <div class="loader"></div>
    </div>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/typed/typed.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/isotope/isotope.pkgd.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>