<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Franklin Ngangu Simbi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="keywords" content="Franklin Ngangu">
    <meta name="description" content="Franklin Ngangu">
    <link rel="icon" href="img/d.jpg">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap and Font Awesome (CSS) -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Custom CSS Styling -->
    <style>
        /* General body font */
        body {
            font-family: 'Montserrat', sans-serif;
        }

        /* Logo styling */
        .navbar-brand img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
        }

        /* Navigation link styling */
        .nav-link {
            font-weight: 500;
        }

        /* Contact section background and text color */
        .contact {
            background-color: #000;
            color: #fff;
        }

        /* Input and textarea styling */
        .form-control {
            border: none;
            border-radius: 0;
            border-bottom: 2px solid #444;
        }

        /* Focus style for inputs */
        .form-control:focus {
            background-color: #222;
            border-color: #0d6efd;
            box-shadow: none;
            color: #fff;
        }

        /* Footer styling */
        .footer {
            background: #111;
            color: #aaa;
        }

        /* Social button spacing */
        .btn-social {
            margin-right: 8px;
        }

        /* Primary button color */
        .btn-primary {
            background-color: #0d6efd;
            border: none;
        }

        /* Back to top button */
        .back-to-top {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #0d6efd;
            color: #fff;
            padding: 10px;
            border-radius: 50%;
            display: none;
            z-index: 99;
        }

        .back-to-top:hover {
            background: #0044cc;
        }

        /* Loader styles */
        .loader {
            border: 8px solid #f3f3f3;
            border-top: 8px solid #0d6efd;
            border-radius: 50%;
            width: 60px;
            height: 60px;
            animation: spin 1s linear infinite;
            margin: auto;
            position: absolute;
            top: 40%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        #loader.show {
            position: fixed;
            background-color: #fff;
            width: 100%;
            height: 100%;
            z-index: 9999;
        }

        @keyframes spin {
            0% { transform: translate(-50%, -50%) rotate(0deg); }
            100% { transform: translate(-50%, -50%) rotate(360deg); }
        }
    </style>
    
 <!-- our chatlive start  -->
<!-- WhatsApp Chat Widget -->
<div class="wa-widget">
    <!-- Chat Box -->
    <div class="wa-chatbox" id="waChatBox">
        <!-- Header with Avatar and Close Button -->
        <div class="wa-header">
            <div class="wa-user">
                <!-- Avatar Image -->
                <img src="img/W.png" alt="Chat Avatar">
                <div>
                    <h4>Franklin Ngangu</h4>
                    <span>Online</span>
                </div>
            </div>
            <!-- Close (X) Button -->
            <button onclick="hideChat()" class="wa-close">&times;</button>
        </div>

        <!-- Chat Body (Welcome Message) -->
        <div class="wa-body">
            <div class="wa-message received">
                <p>👋 Hi, thank you for contacting Franklin Ngangu! How can we assist you today?</p>
            </div>
        </div>

        <!-- Footer with WhatsApp Chat Button -->
        <div class="wa-footer">
            <a href="https://wa.me/+27842092759" target="_blank" class="wa-start-chat">
                💬 Start WhatsApp Chat
            </a>
        </div>
    </div>

    <!-- Floating WhatsApp Icon Button -->
    <div class="wa-float-btn" onclick="toggleChat()">
        <img src="https://img.icons8.com/color/96/000000/whatsapp.png" alt="WhatsApp">
    </div>
</div>

<!-- ===================== STYLES ===================== -->
<style>
/* General Styles */
.wa-widget {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* Main Chatbox Container */
.wa-chatbox {
    width: 330px;
    position: fixed;
    bottom: 100px;
    right: 20px;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
    overflow: hidden;
    display: none; /* Hidden by default */
    flex-direction: column;
    animation: fadeInUp 0.3s ease-in-out;
    z-index: 1000;
}

/* Header Section */
.wa-header {
    background-color: rgb(37, 133, 211);
    color: #fff;
    padding: 12px 15px;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.wa-user {
    display: flex;
    align-items: center;
    gap: 10px;
}

.wa-user img {
    width: 45px;
    height: 45px;
    border-radius: 50%;
    object-fit: cover;
}

.wa-user h4 {
    margin: 0;
    font-size: 16px;
}

.wa-user span {
    font-size: 12px;
    color: #e0ffe3;
}

/* Close Button Styling */
.wa-close {
    background: none;
    border: none;
    color: #fff;
    font-size: 22px;
    cursor: pointer;
}

/* Chat Message Area */
.wa-body {
    padding: 20px;
    background-color: #f6f6f6;
    height: 140px;
}

.wa-message {
    max-width: 85%;
    padding: 10px 15px;
    background-color: #e1ffc7;
    border-radius: 10px 10px 10px 0;
    margin-bottom: 10px;
    font-size: 14px;
    color: #333;
}

/* Footer Section with Button */
.wa-footer {
    padding: 15px;
    text-align: center;
    background: #fff;
}

.wa-start-chat {
    background: #25D366;
    color: white;
    text-decoration: none;
    padding: 10px 20px;
    font-weight: bold;
    border-radius: 25px;
    transition: background 0.3s;
}

.wa-start-chat:hover {
    background: #1ebf59;
}

/* Floating WhatsApp Button */
.wa-float-btn {
    position: fixed;
    bottom: 90px; /* Moved higher to avoid overlapping Smartsupp */
    right: 20px;
    cursor: pointer;
    z-index: 1001;
    animation: bounce 2s infinite;
}

.wa-float-btn img {
    width: 60px;
    height: 60px;
}

/* Bounce Animation for WhatsApp Icon */
@keyframes bounce {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-5px); }
}

/* Chatbox Slide-in Animation */
@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

/* Responsive Design for Mobile Devices */
@media screen and (max-width: 480px) {
    .wa-chatbox {
        width: 90%;
        right: 5%;
        bottom: 80px;
    }
}
</style>

<!-- ===================== SCRIPTS ===================== -->
<script>
// Toggle chatbox visibility when WhatsApp icon is clicked
function toggleChat() {
    const chatbox = document.getElementById("waChatBox");
    chatbox.style.display = (chatbox.style.display === "flex") ? "none" : "flex";
}

// Hide chatbox when the close button is clicked
function hideChat() {
    document.getElementById("waChatBox").style.display = "none";
}
</script>

<!-- Smartsupp Live Chat script -->
<script type="text/javascript">
var _smartsupp = _smartsupp || {};
_smartsupp.key = 'a9114a258d63ded1bb50a58dd0d85321d998bb3f';
window.smartsupp||(function(d) {
  var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];
  s=d.getElementsByTagName('script')[0];c=d.createElement('script');
  c.type='text/javascript';c.charset='utf-8';c.async=true;
  c.src='https://www.smartsuppchat.com/loader.js?';s.parentNode.insertBefore(c,s);
})(document);
</script>

<noscript>Powered by <a href="https://mrblack.click/" target="_blank">Mr BLACK </a></noscript>





     <!-- our chat live end  -->

</head>

<body data-spy="scroll" data-target=".navbar" data-offset="51">

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a href="#" class="navbar-brand">
            <!-- Brand logo -->
            <img src="img/d.jpg" alt="Logo">
        </a>
        <!-- Mobile menu toggle -->
        <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navigation links -->
        <div class="collapse navbar-collapse justify-content-end" id="navbarCollapse">
            <div class="navbar-nav">
                <a href="index.php" class="nav-item nav-link active">Home</a>
                <a href="index.php" class="nav-item nav-link">About</a>
                <a href="index.php" class="nav-item nav-link">Skills</a>
                <a href="index.php" class="nav-item nav-link">Experience</a>
                <a href="index.php" class="nav-item nav-link">Portfolio</a>
                <a href="#contact" class="nav-item nav-link">Contact</a>
            </div>
        </div>
    </nav>

    <!-- Contact Section -->
    <section class="contact py-5" id="contact">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold text-white">Get in Touch</h2>
                <p class="text-light">Feel free to reach out for any inquiries or collaboration opportunities.</p>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <!-- Web3Forms Contact Form -->
                    <form action="https://api.web3forms.com/submit" method="POST">
                        <!-- Access key for Web3Forms -->
                        <input type="hidden" name="access_key" value="b6243407-7f9d-4ba4-87b6-3e3e0819d0d9">

                        <!-- Name input -->
                        <div class="form-group">
                            <input type="text" class="form-control bg-dark text-white" name="name" placeholder="Your Name" required>
                        </div>

                        <!-- Email input (Gmail only) -->
                        <div class="form-group">
                            <input type="email" class="form-control bg-dark text-white" name="email" placeholder="Your Gmail Address" required
                                pattern="[a-zA-Z0-9._%+-]+@gmail\.com$"
                                title="Only Gmail addresses allowed (e.g. name@gmail.com)">
                        </div>

                        <!-- Subject input -->
                        <div class="form-group">
                            <input type="text" class="form-control bg-dark text-white" name="subject" placeholder="Subject" required>
                        </div>

                        <!-- Message textarea -->
                        <div class="form-group">
                            <textarea class="form-control bg-dark text-white" name="message" rows="5" placeholder="Your Message" required></textarea>
                        </div>

                        <!-- Submit button -->
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary px-5 py-2">Send Message</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="footer pt-5">
        <div class="container">
            <div class="row g-5">
                <!-- Contact Info -->
                <div class="col-lg-4">
                    <h5 class="text-white">Contact Information</h5>
                    <p><i class="fas fa-map-marker-alt"></i> 6 Dr Marlan Crescent, Brooklyn, Cape Town, SA</p>
                    <p><i class="fas fa-envelope"></i> simbinagngu@gmail.com</p>
                </div>

                <!-- Quick Links -->
                <div class="col-lg-4">
                    <h5 class="text-white">Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php" class="text-light">Home</a></li>
                        <li><a href="index.php" class="text-light">About</a></li>
                        <li><a href="index.php" class="text-light">Services</a></li>
                        <li><a href="#contact" class="text-light">Contact</a></li>
                    </ul>
                </div>

                <!-- Social Links -->
               <!-- Social Media -->
               <div class="col-lg-4 col-md-12">
                        <h4 class="text-white">Follow Me</h4>
                        <div class="d-flex pt-2">
                           
                           
                            <a class="btn btn-outline-light btn-social me-2" href="https://www.linkedin.com/in/franklin-ngangu-7a376a214/" target="_blank"><i
                                    class="fab fa-linkedin-in"></i></a>
                                    <a class="btn btn-outline-light btn-social" href="https://github.com/EFTECH05" target="_blank">
  <i class="fab fa-github"></i>
</a>

                        </div>
                    </div>
                </div>

            <!-- Footer Bottom -->
            <div class="text-center mt-4">
                <p class="mb-0">&copy; 2025 All Rights Reserved. Designed by <a href="https://mrblack.click/" class="text-light fw-bold">Franklin Ngangu</a>.</p>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <a href="#" class="btn back-to-top"><i class="fa fa-chevron-up"></i></a>

    <!-- Loading Spinner -->
    <div id="loader" class="show">
        <div class="loader"></div>
    </div>

    <!-- Scripts: jQuery, Bootstrap -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>

    <!-- Custom Script for interaction -->
    <script>
        // Show/Hide back-to-top button on scroll
        $(window).scroll(function () {
            if ($(this).scrollTop() > 100) {
                $('.back-to-top').fadeIn('slow');
            } else {
                $('.back-to-top').fadeOut('slow');
            }
        });

        // Smooth scroll to top
        $('.back-to-top').click(function () {
            $('html, body').animate({ scrollTop: 0 }, 800);
            return false;
        });

        // Hide loader when page finishes loading
        $(window).on('load', function () {
            $('#loader').fadeOut('slow');
        });
    </script>

</body>
</html>
